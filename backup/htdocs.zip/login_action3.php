<?php
    session_start();
    $python = `mouth.py`;


    if(strpos($python,$_SESSION['mouth'])==true){
    ?>      <script>

                alert("2차 입모양 성공");
                location.replace("./login_action4.php");
            </script>
<?php
        }
     else{
         ?>      <script>

                     alert("로그인 실패");
                     location.replace("./login.php");
                 </script>
<?php

     }


?>