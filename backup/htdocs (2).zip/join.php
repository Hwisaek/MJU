<!DOCTYPE>
 
<html>
<head>
        <meta charset='utf-8'>
</head>
<body>
 
        <div align="center">
                <p>회원가입</p>

                <form method='get' action='join_action.php'>
                        <p>ID: <input type="text" name="id"></p>
                        <p>PW: <input type="password" name="pw"></p>
                        <p>Email: <input type="email" name="email"></p>
                        <p>name:<input type = "name" name = "name"></p>
                        <p>mouth:<input type = "mouth" name = "mouth"></p>
                        <p>eye:<input ytpe = "eye" name = "eye"></p>

                        <input type="submit" value="회원가입">

                </form>

        </div>
</body>
</html>


